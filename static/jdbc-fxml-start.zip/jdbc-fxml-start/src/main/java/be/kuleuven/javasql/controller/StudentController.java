package be.kuleuven.javasql.controller;

public class StudentController {

    public void initialize() {
        // TODO
    }
}
