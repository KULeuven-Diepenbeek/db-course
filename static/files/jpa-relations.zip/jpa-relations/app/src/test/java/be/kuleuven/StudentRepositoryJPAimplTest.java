package be.kuleuven;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class StudentRepositoryJPAimplTest extends StudentRepositoryTest {
  private ConnectionManager connectionManager;
  private SessionFactory sessionFactory;
  private EntityManager entityManager;

  @Before
  public void createDatabaseAndInitializeConnectionManager() {
    this.connectionManager = new ConnectionManager(super.CONNECTIONSTRING_TO_TEST_DB, "", "");
    connectionManager.initTables();
    connectionManager.verifyTableContentOfInit();
    try {
      connectionManager.getConnection().commit();
    } catch (SQLException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }
    this.sessionFactory = (SessionFactory) Persistence.createEntityManagerFactory("be.kuleuven.studenthibernateTest");
    this.entityManager = sessionFactory.createEntityManager();
    super.studentRepository = new StudentRepositoryJPAimpl(entityManager);
    assertNotNull("StudentRepository must be initialized by the subclass", super.studentRepository);
  }

  @After
  public void closeConnections() {
    try {
      if (this.entityManager != null && this.entityManager.isOpen()) {
        this.entityManager.clear(); // detach all managed entities
        this.entityManager.close(); // close the persistence context
      }

      if (this.sessionFactory != null && this.sessionFactory.isOpen()) {
        this.sessionFactory.close(); // free metadata caches, connection pools
      }

      connectionManager.getConnection().close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  @Test
  public void givenNewStudent_whenAddStudentToDb_assertThatStudentIsInDb() {
    super.givenNewStudent_whenAddStudentToDb_assertThatStudentIsInDb();
  }

  @Test
  public void givenNewStudenThatAlreadyInDb_whenAddStudentToDb_assertThrowsRuntimeException() {
    super.givenNewStudenThatAlreadyInDb_whenAddStudentToDb_assertThrowsRuntimeException();
  }

  @Test
  public void given123_whenGetStudentsByStudnr_assertThatStudentIsJaakTrekhaak() {
    super.given123_whenGetStudentsByStudnr_assertThatStudentIsJaakTrekhaak();
  }

  @Test
  public void givenWrongStudnr_whenGetStudentsByStudnr_assertThatThrowsInvalidStudentException() {
    super.givenWrongStudnr_whenGetStudentsByStudnr_assertThatThrowsInvalidStudentException();
  }

  @Test
  public void whenGetAllStudents_assertThat3correctStudentsPresent() {
    super.whenGetAllStudents_assertThat3correctStudentsPresent();
  }

  @Test
  public void givenStudent123updateToJacqueline_whenUpdateStudentInDb_assertThatStudentIsInDb() {
    super.givenStudent123updateToJacqueline_whenUpdateStudentInDb_assertThatStudentIsInDb();
  }

  @Test
  public void givenStudentNotInDb_whenUpdateStudentInDb_assertThatThrowsInvalidStudentException() {
    super.givenStudentNotInDb_whenUpdateStudentInDb_assertThatThrowsInvalidStudentException();
  }

  @Test
  public void givenStudent123delete_whenDeleteStudentInDb_assertThatStudentIsNoLongerInDb() {
    super.givenStudent123delete_whenDeleteStudentInDb_assertThatStudentIsNoLongerInDb();
  }

  @Test
  public void givenStudentNotInDb_whenDeleteStudentInDb_assertThatThrowsInvalidStudentException() {
    super.givenStudentNotInDb_whenDeleteStudentInDb_assertThatThrowsInvalidStudentException();
  }

}
