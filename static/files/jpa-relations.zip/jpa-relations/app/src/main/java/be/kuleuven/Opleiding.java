package be.kuleuven;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "opleiding")
public class Opleiding {
  @Id
  private int id;

  @Column(name = "opleidingsnaam")
  private String naam;

  // One-to-many relatie met Student
  @OneToMany(mappedBy = "opleiding")
  private List<Student> inschrijvingen;

  // Constructors
  public Opleiding() {
  }

  public Opleiding(int id, String naam) {
    this.id = id;
    this.naam = naam;
  }

  // Getters en Setters
  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getNaam() {
    return naam;
  }

  public void setNaam(String naam) {
    this.naam = naam;
  }

  public List<Student> getInschrijvingen() {
    return inschrijvingen;
  }

  public void setInschrijvingen(List<Student> inschrijvingen) {
    this.inschrijvingen = inschrijvingen;
  }

  // toString, equals en hashCode
  @Override
  public String toString() {
    return "Opleiding{" +
        "id=" + id +
        ", naam='" + naam + '\'' +
        '}';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o)
      return true;
    if (!(o instanceof Opleiding))
      return false;
    Opleiding that = (Opleiding) o;
    return id == that.id;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }
}
