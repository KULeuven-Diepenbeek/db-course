package be.kuleuven;

import java.util.List;

public interface StudentRepository {
  public void addStudentToDb(Student student);

  public Student getStudentsByStudnr(int stud_nr);

  public List<Student> getAllStudents();

  public void updateStudentInDb(Student student);

  public void deleteStudentInDb(int studnr);

}
