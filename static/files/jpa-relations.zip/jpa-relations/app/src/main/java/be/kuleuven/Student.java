package be.kuleuven;

import javax.persistence.*;

import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "student")
public class Student {
  @Id
  private int studnr;

  @Column(name = "voornaam")
  private String voornaam;

  @Column(name = "naam")
  private String naam;

  @Column(name = "goedbezig")
  private boolean goedBezig;

  // Many-to-one relatie met Opleiding
  @ManyToOne
  @JoinColumn(name = "opleiding")
  private Opleiding opleiding;

  // Many-to-many relatie met Vak via de join table 'student_volgt_vak'
  @ManyToMany
  @JoinTable(name = "student_volgt_vak", joinColumns = @JoinColumn(name = "student"), inverseJoinColumns = @JoinColumn(name = "vak"))
  private List<Vak> vakken;

  // Constructors
  public Student() {
  }

  public Student(int studnr, String naam, String voornaam, boolean goedBezig) {
    this.studnr = studnr;
    this.naam = naam;
    this.voornaam = voornaam;
    this.goedBezig = goedBezig;
  }

  // Getters en Setters
  public int getStudnr() {
    return studnr;
  }

  public void setStudnr(int studnr) {
    this.studnr = studnr;
  }

  public String getVoornaam() {
    return voornaam;
  }

  public void setVoornaam(String voornaam) {
    this.voornaam = voornaam;
  }

  public String getNaam() {
    return naam;
  }

  public void setNaam(String achternaam) {
    this.naam = achternaam;
  }

  public boolean isGoedBezig() {
    return goedBezig;
  }

  public void setGoedBezig(boolean goedBezig) {
    this.goedBezig = goedBezig;
  }

  public Opleiding getOpleiding() {
    return opleiding;
  }

  public void setOpleiding(Opleiding opleiding) {
    this.opleiding = opleiding;
  }

  public List<Vak> getVakken() {
    return vakken;
  }

  public void setVakken(List<Vak> vakken) {
    this.vakken = vakken;
  }

  // toString, equals en hashCode
  @Override
  public String toString() {
    return "Student{" +
        "studnr=" + studnr +
        ", voornaam='" + voornaam + '\'' +
        ", achternaam='" + naam + '\'' +
        ", goedBezig=" + goedBezig +
        '}';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o)
      return true;
    if (!(o instanceof Student))
      return false;
    Student student = (Student) o;
    return studnr == student.studnr;
  }

  @Override
  public int hashCode() {
    return Objects.hash(studnr);
  }
}
