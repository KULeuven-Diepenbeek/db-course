package be.kuleuven;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import java.util.List;

public class StudentRepositoryJPAimpl implements StudentRepository {
  private final EntityManager em;

  public static void main(String[] args) {
    // WIL JE DEZE CODE GEBRUIKEN OM DE DATABASE OP TE ZETTEN VERWIJDER DAN DE OPTIE schema-generation.database.action IN persistence.xml
    ConnectionManager cm = new ConnectionManager("jdbc:mysql://localhost:3306/school?allowMultiQueries=true",
        "root", "");
    cm.initTables();
    cm.verifyTableContentOfInit();
    cm.flushConnection();

    // CODE HIERBOVEN IS NIET NODIG ALS JE EEN import.sql FILE HEBT, WEL OOK NOG IN persistence.xml DE OPTION schema-generation.database.action OP drop-and-create ZETTEN
    var sessionFactory = Persistence.createEntityManagerFactory("be.kuleuven.studenthibernate");
    var entityManager = sessionFactory.createEntityManager();
    StudentRepository sr = new StudentRepositoryJPAimpl(entityManager);

    Student s = sr.getStudentsByStudnr(123);
    List<Vak> vakken = s.getVakken();
    Opleiding o = s.getOpleiding();

    System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n------------STARTING APPLICATION------------\n");
    System.out.println("");
    System.out.println(o);
    System.out.println(vakken.size());
    for (Vak v : vakken) {
      System.out.println(v);
    }
  }

  public StudentRepositoryJPAimpl(EntityManager em) {
    this.em = em;
  }

  @Override
  public void addStudentToDb(Student student) {
    em.getTransaction().begin();
    em.persist(student);
    em.getTransaction().commit();
  }

  @Override
  public Student getStudentsByStudnr(int studnr) {
    Student student = em.find(Student.class, studnr);
    if (student == null) {
      throw new InvalidStudentException(String.valueOf(studnr));
    }
    return student;
  }

  @Override
  public List<Student> getAllStudents() {
    // MEER MANUEEL
    // TypedQuery<Student> query = em.createQuery("SELECT s FROM Student s", Student.class);
    // return query.getResultList();

    // MEER DE JPA STIJL
    CriteriaBuilder cb = em.getCriteriaBuilder();
    CriteriaQuery<Student> cq = cb.createQuery(Student.class);
    Root<Student> root = cq.from(Student.class);
    cq.select(root);
    return em.createQuery(cq).getResultList();
  }

  @Override
  public void updateStudentInDb(Student student) {
    em.getTransaction().begin();
    if (em.find(Student.class, student.getStudnr()) == null) {
      throw new InvalidStudentException(String.valueOf(student.getStudnr()));
    }
    em.merge(student);
    em.getTransaction().commit();
  }

  @Override
  public void deleteStudentInDb(int studnr) {
    em.getTransaction().begin();
    Student student = em.find(Student.class, studnr);
    if (student == null) {
      throw new InvalidStudentException(String.valueOf(studnr));
    }
    em.remove(student);
    em.getTransaction().commit();
  }
}
