package be.kuleuven;

import javax.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "vak")
public class Vak {
  @Id
  private int vaknr;

  @Column(name = "vaknaam")
  private String naam;

  // Many-to-many relatie met Student (de andere kant van de relatie)
  @ManyToMany(mappedBy = "vakken")
  private List<Student> studenten;

  // Constructors
  public Vak() {
  }

  public Vak(int vaknr, String naam) {
    this.vaknr = vaknr;
    this.naam = naam;
  }

  // Getters en Setters
  public int getVaknr() {
    return vaknr;
  }

  public void setVaknr(int vaknr) {
    this.vaknr = vaknr;
  }

  public String getNaam() {
    return naam;
  }

  public void setNaam(String naam) {
    this.naam = naam;
  }

  public List<Student> getStudenten() {
    return studenten;
  }

  public void setStudenten(List<Student> studenten) {
    this.studenten = studenten;
  }

  // toString, equals en hashCode
  @Override
  public String toString() {
    return "Vak{" +
        "vaknr=" + vaknr +
        ", naam='" + naam + '\'' +
        '}';
  }

  @Override
  public boolean equals(Object o) {
    if (this == o)
      return true;
    if (!(o instanceof Vak))
      return false;
    Vak vak = (Vak) o;
    return vaknr == vak.vaknr;
  }

  @Override
  public int hashCode() {
    return Objects.hash(vaknr);
  }
}
