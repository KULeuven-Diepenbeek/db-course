package be.kuleuven;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.OperationNotSupportedException;

import org.jdbi.v3.core.Jdbi;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class StudentRepositoryJDBIimpl implements StudentRepository {
  private final Jdbi jdbi;

  public StudentRepositoryJDBIimpl(String connectionString, String user, String pwd) {
    jdbi = Jdbi.create(connectionString, user, pwd);
  }

  public Jdbi getJdbi() {
    return jdbi;
  }

  // CREATE
  public void addStudentToDb(Student student) {
    jdbi.withHandle(handle -> {
      return handle.execute("INSERT INTO student (studnr, naam, voornaam, goedBezig) VALUES (?, ?, ?, ?)",
          student.getStudnr(), student.getNaam(), student.getVoornaam(), student.isGoedBezig());

      //            return handle.createUpdate("INSERT INTO student (studnr, naam, voornaam, goedBezig) VALUES (:studnr, :naam, :voornaam, :goedBezig)")
      //                    .bindBean(student)
      //                    .execute();
    });
  }

  // READ
  public Student getStudentsByStudnr(int stud_nr) {
    return (Student) jdbi.withHandle(handle -> {
      return handle.createQuery("SELECT * FROM student WHERE studnr = :nummer")
          .bind("nummer", stud_nr)
          .mapToBean(Student.class)
          .first();
    });
  }

  // READ: Extra
  public List<Student> getAllStudents() {
    return jdbi.withHandle(handle -> {
      return handle.createQuery("SELECT * FROM student")
          .mapToBean(Student.class)
          .list();
    });
  };

  // UPDATE
  public void updateStudentInDb(Student student) {
    int affectedRows = jdbi.withHandle(handle -> {
      return handle
          .createUpdate(
              "UPDATE student SET naam = :naam, voornaam = :voornaam, goedbezig = :goedBezig WHERE studnr = :studnr;")
          .bindBean(student)
          .execute();
    });
    if (affectedRows == 0) {
      throw new InvalidStudentException(student.getStudnr() + "");
    }
  }

  // DELETE
  public void deleteStudentInDb(int studnr) {
    int affectedRows = jdbi.withHandle(handle -> {
      return handle
          .createUpdate(
              "DELETE FROM student WHERE studnr = :nummer")
          .bind("nummer", studnr)
          .execute();
    });
    if (affectedRows == 0) {
      throw new InvalidStudentException(studnr + "");
    }
  }
}
