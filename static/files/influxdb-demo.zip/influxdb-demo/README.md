
### Opdracht: tennisspelers NoSql
Je krijgt alweer een startproject met de `Speler` en `Club` klasse gegeven, je krijgt ook al de start van de `SpelerRepository` klasse waarvan je weer zelf de implementaties van de gevraagde methoden moet programmeren volgens de `TODO`s zodat alle testen slagen. Alle dependencies en imports zijn al ingevoegd en correct, het kan echter zijn dat voor jouw manier een extra import nodig is. **Je moet er ook wel voor zorgen dat je op je lokale MongoDb server al een database hebt met de naam "Tennisvlaanderen" en een collectie "spelers". Dit kan je eenvoudig doen via de MongoDb Compass GUI zoals we in de les gezien hebben.**

Een speler ziet er als volgt uit (en je mag ervan uitgaan dat elk json object altijd de nodige properties heeft om het om te zetten naar een Java Speler object):
```json
{
    "tennisvlaanderenId": 1,
    "naam": "Tom Janssens",
    "punten": 10,
    "prof": true,
    "club": {
      "naam": "T.P.Tessenderlo",
      "gemeente": "Tessenderlo-Ham"
    },
    "likedTennisvlaanderenIds": [
      2,
      3
    ]
  }
```


**Push voor de deadline van vrijdag 9 mei 2025 23u59 je oplossingen naar je repository**