package be.kuleuven;

import java.time.LocalDateTime;

public class CO2Point {
  private double co2_concentration;
  private LocalDateTime time;

  // Empty constructor
  public CO2Point() {
  }

  // Constructor with all parameters
  public CO2Point(double co2_concentration, LocalDateTime time) {
    this.co2_concentration = co2_concentration;
    this.time = time;
  }

  // Getters and setters
  public double getCo2_concentration() {
    return co2_concentration;
  }

  public void setCo2_concentration(double co2_concentration) {
    this.co2_concentration = co2_concentration;
  }

  public LocalDateTime getTime() {
    return time;
  }

  public void setTime(LocalDateTime time) {
    this.time = time;
  }

  // Equals method
  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null || getClass() != obj.getClass())
      return false;
    CO2Point co2Point = (CO2Point) obj;
    return Double.compare(co2Point.co2_concentration, co2_concentration) == 0 && time.equals(co2Point.time);
  }

  // Hash method
  @Override
  public int hashCode() {
    int result = Double.hashCode(co2_concentration);
    result = 31 * result + time.hashCode();
    return result;
  }

  // ToString method
  @Override
  public String toString() {
    return "TempPoint{" +
        "temperature=" + co2_concentration +
        ", time=" + time +
        '}';
  }

  // Method to convert LocalDateTime to milliseconds
  public static long timeToMillis(LocalDateTime time) {
    return time.atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();
  }

  // Method to convert milliseconds to LocalDateTime
  public static LocalDateTime millisToTime(long millis) {
    return LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(millis), java.time.ZoneId.systemDefault());
  }
}
