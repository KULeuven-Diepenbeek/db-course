package be.kuleuven;

import java.util.Objects;

public class Opleiding {
  private String naam;
  private String keuze;

  // Empty constructor
  public Opleiding() {
  }

  // Full constructor
  public Opleiding(String naam, String keuze) {
    this.naam = naam;
    this.keuze = keuze;
  }

  // Getters and Setters
  public String getNaam() {
    return naam;
  }

  public void setNaam(String naam) {
    this.naam = naam;
  }

  public String getKeuze() {
    return keuze;
  }

  public void setKeuze(String keuze) {
    this.keuze = keuze;
  }

  // toString method
  @Override
  public String toString() {
    return "Opleiding{" +
        "naam='" + naam + '\'' +
        ", keuze='" + keuze + '\'' +
        '}';
  }

  // equals and hashCode methods
  @Override
  public boolean equals(Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    Opleiding opleiding = (Opleiding) o;
    return Objects.equals(naam, opleiding.naam) && Objects.equals(keuze, opleiding.keuze);
  }

  @Override
  public int hashCode() {
    return Objects.hash(naam, keuze);
  }
}
