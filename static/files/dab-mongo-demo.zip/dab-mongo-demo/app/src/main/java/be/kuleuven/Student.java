package be.kuleuven;

import java.util.List;
import java.util.Objects;

public class Student {
  private int studnr;
  private String naam;
  private String voornaam;
  private boolean goedBezig;
  private Opleiding opleiding;
  private List<String> vakken;

  // Empty constructor
  public Student() {
  }

  // Full constructor
  public Student(int studnr, String naam, String voornaam, boolean goedBezig, Opleiding opleiding,
      List<String> vakken) {
    this.studnr = studnr;
    this.naam = naam;
    this.voornaam = voornaam;
    this.goedBezig = goedBezig;
    this.opleiding = opleiding;
    this.vakken = vakken;
  }

  // Getters and Setters
  public int getStudnr() {
    return studnr;
  }

  public void setStudnr(int studnr) {
    this.studnr = studnr;
  }

  public String getNaam() {
    return naam;
  }

  public void setNaam(String naam) {
    this.naam = naam;
  }

  public String getVoornaam() {
    return voornaam;
  }

  public void setVoornaam(String voornaam) {
    this.voornaam = voornaam;
  }

  public boolean isGoedBezig() {
    return goedBezig;
  }

  public void setGoedBezig(boolean goedBezig) {
    this.goedBezig = goedBezig;
  }

  public Opleiding getOpleiding() {
    return opleiding;
  }

  public void setOpleiding(Opleiding opleiding) {
    this.opleiding = opleiding;
  }

  public List<String> getVakken() {
    return vakken;
  }

  public void setVakken(List<String> vakken) {
    this.vakken = vakken;
  }

  // toString method
  @Override
  public String toString() {
    return "Student{" +
        "studnr=" + studnr +
        ", naam='" + naam + '\'' +
        ", voornaam='" + voornaam + '\'' +
        ", goedBezig=" + goedBezig +
        ", opleiding=" + opleiding +
        ", vakken=" + vakken +
        '}';
  }

  // equals and hashCode methods
  @Override
  public boolean equals(Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;
    Student student = (Student) o;
    return studnr == student.studnr && goedBezig == student.goedBezig && Objects.equals(naam, student.naam)
        && Objects.equals(voornaam, student.voornaam) && Objects.equals(opleiding, student.opleiding)
        && Objects.equals(vakken, student.vakken);
  }

  @Override
  public int hashCode() {
    return Objects.hash(studnr, naam, voornaam, goedBezig, opleiding, vakken);
  }
}
