package be.kuleuven;

import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.bson.*;
import org.bson.conversions.Bson;

import com.mongodb.client.*;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Accumulators;
import com.google.gson.*;

public class StudentRepository {
  public final static String DB_URI = "mongodb://localhost:27017";;
  public final static String DB_NAME = "School";
  public final static String DB_COLLECTION = "studenten";

  private MongoClient mongoClient;
  private MongoDatabase database;
  private MongoCollection<Document> collection;

  public static void main(String[] args) {
    try {
      URI path = Objects.requireNonNull(App.class.getClassLoader().getResource("initDb.json")).toURI();
      var jsonArray = new String(Files.readAllBytes(Paths.get(path)));
      MongoClient mongoClient = MongoClients.create(DB_URI);
      MongoDatabase database = mongoClient.getDatabase(DB_NAME);
      MongoCollection<Document> collectie = database.getCollection(DB_COLLECTION);

      collectie.deleteMany(new Document());

      List<Document> documents = new ArrayList<>();
      for (JsonElement element : JsonParser.parseString(jsonArray).getAsJsonArray()) {
        documents.add(Document.parse(element.toString()));
      }
      // Insert the documents into the collection
      collectie.insertMany(documents);

      Gson gson = new GsonBuilder().create();
      ArrayList<Student> studenten = new ArrayList<>();

      for (Document doc : collectie.find()) {
        Student s = gson.fromJson(doc.toJson(), Student.class);
        System.out.println(s.getStudnr());
        studenten.add(s);
      }

    } catch (Exception e) {
      e.printStackTrace();
      throw new RuntimeException();
    }
  }

  public StudentRepository() {
    try {
      URI path = Objects.requireNonNull(App.class.getClassLoader().getResource("initDb.json")).toURI();
      var jsonArray = new String(Files.readAllBytes(Paths.get(path)));

    } catch (Exception e) {
      e.printStackTrace();
      throw new RuntimeException();
    }

  }

  public void createDatabase() {

  }

  public void destroyDatabase() {

  }

}
