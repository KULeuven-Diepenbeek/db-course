package be.kuleuven.javasql.jdbi;

public class StudentRepositoryJdbi3ImplTest {
    // TODO
}
