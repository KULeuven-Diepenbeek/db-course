//
// Created by Wouter Groeneveld on 22/08/18.
//

#ifndef GBA_ARKANOID_TYPEDEFS_H
#define GBA_ARKANOID_TYPEDEFS_H

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;

#endif //GBA_ARKANOID_TYPEDEFS_H
