//
// Created by Wouter Groeneveld on 22/08/18.
//

#include "Ball.h"

void Ball::updatePositionDependingOnPaddle(GameObject* paddle) {
    auto ball = this;
    x += dx;
    y += dy;

    if(ball->x <= 0 || ball->x >= (maxX - ball->w)) {
        ball->dx = -ball->dx;
    }
    if(ball->y <= 0 || ball->collidesWith(paddle)) {
        ball->dy = -ball->dy;
    }
}
