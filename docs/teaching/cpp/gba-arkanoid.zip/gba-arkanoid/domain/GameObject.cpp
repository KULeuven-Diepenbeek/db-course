//
// Created by Wouter Groeneveld on 22/08/18.
//

#include <cstdlib>
#include "GameObject.h"

void GameObject::updatePositionDependingOnVelocity() {
    auto s = this;
    s->x += s->dx;
    if(s->x < 0) s->x = 0;
    if(s->x > (maxX - s->w)) s->x = maxX - s->w;

    s->y += s->dy;
    if(s->y < 0) s->y = 0;
    if(s-> y > (maxY - s->h)) s->y = maxY - s->h;
}

bool GameObject::collidesWith(GameObject *o) {
    auto s = this;
    if((abs(s->x - o->x) < (s->w + o->w) / 2)
       && abs(s->y - o->y) < (s->h + o->h) / 2) {
        return 1;
    }
    return 0;
}
