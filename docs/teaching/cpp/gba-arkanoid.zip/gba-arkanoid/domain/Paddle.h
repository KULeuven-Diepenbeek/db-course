//
// Created by Wouter Groeneveld on 22/08/18.
//

#ifndef GBA_ARKANOID_PADDLE_H
#define GBA_ARKANOID_PADDLE_H


#include "GameObject.h"

class Paddle : public GameObject {

};


#endif //GBA_ARKANOID_PADDLE_H
