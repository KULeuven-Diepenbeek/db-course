//
// Created by Wouter Groeneveld on 22/08/18.
//

#ifndef GBA_ARKANOID_BALL_H
#define GBA_ARKANOID_BALL_H


#include "GameObject.h"
#include "Paddle.h"

class Ball : public GameObject {
public:
    void updatePositionDependingOnPaddle(GameObject* p);
};


#endif //GBA_ARKANOID_BALL_H
