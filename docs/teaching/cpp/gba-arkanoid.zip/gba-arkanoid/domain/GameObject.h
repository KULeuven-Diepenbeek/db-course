//
// Created by Wouter Groeneveld on 22/08/18.
//

#ifndef GBA_ARKANOID_GAMEOBJECT_H
#define GBA_ARKANOID_GAMEOBJECT_H


#include "../typedefs.h"

class GameObject {
protected:
    int x, y;
    int maxX, maxY;
    int dx, dy;
    u8 w, h;
    bool hidden;

public:
    bool isHidden() { return hidden; }
    int getX() { return x; }
    int getY() { return y; }
    int getDx() { return dx; }
    int getDy() { return dy; }
    int getW() { return w; }
    int getH() { return h; }

    void hide() { hidden = true; }
    void setMax(int x, int y) { maxX = x; maxY = y; }
    void updateDimensions(u8 w, u8 h) { this->w = w; this->h = h; }
    void updatePos(int x, int y) { this->x = x; this->y = y; }
    void updateVelocity(int dx, int dy) { this->dx = dx; this->dy = dy; }

    virtual void updatePositionDependingOnVelocity();
    bool collidesWith(GameObject* other);

};


#endif //GBA_ARKANOID_GAMEOBJECT_H
