//
// Created by Wouter Groeneveld on 22/08/18.
//

#ifndef GBA_ARKANOID_SPRITE_H
#define GBA_ARKANOID_SPRITE_H


#include "../typedefs.h"
#include "../domain/GameObject.h"
#include "gbadefs.h"

typedef struct object {
    u16 attr0;
    u16 attr1;
    u16 attr2;
    u16 unused;
} __attribute__((packed, aligned(4))) object;

template<typename T> class Sprite {
private:
    T* gameObj;
    volatile object *oamObj;

    void hideInOAM();
    Sprite() : gameObj(new T()) {  }

public:
    void updatePositionDependingOnVelocity();
    bool collidesWith(GameObject* other);

    volatile object* getOam() { return oamObj; }
    T* getObj() { return gameObj; }

    void positionInOAM();
    bool isHidden();
    void hide();
    void updateVelocity(int dx, int dy) { this->gameObj->updateVelocity(dx, dy); }
    void updatePos(int x, int y) { this->gameObj->updatePos(x, y); }
    int getX() { return gameObj->getX(); }
    int getY() { return gameObj->getY(); }
    void dX(int x) {
        this->gameObj->updateVelocity(x, this->gameObj->getDy());
    }
    void dY(int y) {
        this->gameObj->updateVelocity(this->gameObj->getDx(), y);
    }

    static Sprite<T>* create(volatile object* obj, int intialx, int initialy, u8 w, u8 h);
};

template<typename T> Sprite<T>* Sprite<T>::create(volatile object* obj, int intialx, int initialy, u8 w, u8 h) {
    auto s = new Sprite();
    s->gameObj->setMax(SCREEN_WIDTH, SCREEN_HEIGHT);

    s->oamObj = obj;
    s->gameObj->updatePos(intialx, initialy);
    s->gameObj->updateDimensions(w, h);

    s->positionInOAM();
    return s;
}

template<typename T> void Sprite<T>::positionInOAM() {
    volatile object *obj = this->oamObj;
    int x = this->gameObj->getX();
    int y = this->gameObj->getY();
    obj->attr0 = (obj->attr0 &  ~OAM_Y_MASK) | (y & OAM_Y_MASK);
    obj->attr1 = (obj->attr1 & ~OAM_X_MASK) | (x & OAM_X_MASK);
}


template<typename T> void Sprite<T>::updatePositionDependingOnVelocity() {
    gameObj->updatePositionDependingOnVelocity();
}

template<typename T> bool Sprite<T>::collidesWith(GameObject *o) {
    return gameObj->collidesWith(o);
}

template<typename T> bool Sprite<T>::isHidden() {
    return gameObj->isHidden();
}

template<typename T> void Sprite<T>::hideInOAM() {
    volatile object *obj = obj;
    obj->attr0 = (obj->attr0 & ~OAM_HIDE_MASK) | OAM_HIDE;
}

template<typename T> void Sprite<T>::hide() {
    gameObj->hide();
    hideInOAM();
}

#endif //GBA_ARKANOID_SPRITE_H
