#include <stdlib.h>
#include "../typedefs.h"
#include "Sprite.h"
#include "gbadefs.h"
#include "../domain/Ball.h"
#include "../domain/Paddle.h"
#include "../domain/GameObject.h"


void vsync() {
    while (REG_VCOUNT >= 160);
    while (REG_VCOUNT < 160);
}

u16 color(u16 r, u16 g, u16 b) {
    u16 c = (b & 0x1f) << 10;
    c |= (g & 0x1f) << 5;
    c |= (r & 0x1f);
    return c;
}

int next_oam_mem;
int next_tile_mem = 1;

volatile object* create_object(int attr0, int attr1, int attr2) {
    volatile object *obj = &OAM_MEM[next_oam_mem++];
    obj->attr0 = attr0;
    obj->attr1 = attr1;
    obj->attr2 = attr2;

    return obj;
}

volatile object* copy_object(volatile object* other) {
    return create_object(other->attr0, other->attr1, other->attr2);
}

Sprite<GameObject>* create_object(volatile object* obj, int intialx, int initialy, u8 w, u8 h) {
    return Sprite<GameObject>::create(obj, intialx, initialy, w, h);
}

Sprite<Ball>* create_ball(volatile object* obj, int intialx, int initialy, u8 w, u8 h) {
    return Sprite<Ball>::create(obj, intialx, initialy, w, h);
}

Sprite<Paddle>* create_paddle(volatile object* obj, int intialx, int initialy, u8 w, u8 h) {
    return Sprite<Paddle>::create(obj, intialx, initialy, w, h);
}

volatile object* create_paddle() {
    // 1. kleur
    PALETTE_MEM[0][2] = color(31, 0, 0);

    // 2. tile - vanaf hieronder alles bezet tot TILE_MEM[4][6]!
    volatile u16 *paddle_tile = (u16*) TILE_MEM[TILE_MEM_FG][next_tile_mem];  // begin vanaf 2
    next_tile_mem += 4;
    // vul de tile met de palet index 2 - dit is per rij, vandaar 0x2222
    for(int i = 0; i < 4 * sizeof(tile_4bpp) / 2; i++) {
        paddle_tile[i] = 0x2222;
    }

    // 3. object: 4bpp, wide - 32x8 met wide shape - vanaf de 2de tile, palet 0
    return create_object(0x4000,  0x4000, 2);
}

volatile object* create_ball() {
    // 1. kleur
    PALETTE_MEM[0][1] = color(31, 31, 31); // wit - zie labo 3

    // 2. tile
    volatile u16 *ball_tile = (u16*) TILE_MEM[TILE_MEM_FG][next_tile_mem];  // 1 block
    next_tile_mem++;
    // vul de tile met de palet index 1 - dit is per rij, vandaar 0x1111
    for(int i = 0; i < sizeof(tile_4bpp) / 2; i++) {
        ball_tile[i] = 0x1111;
    }

    // 3. object: 4bpp, square - grootte 8x8 met square - eerste tile, palet 0
    return create_object(0, 0, 1);
}

void initScreen() {
    REG_DISPLAY = DISPLAY_MODE1 | DISPLAY_ENABLE_OBJECTS;
}

u16 readKeys() {
    return ~REG_KEY_INPUT & KEY_ANY;
}


int you_died() {
    return 0;
}

int main() {
    u16 keys, score = 0;
    auto ball = create_ball(create_ball(), 50, 50, 8, 8);
    ball->updateVelocity(2, 1);

    auto paddle = create_paddle(create_paddle(), (SCREEN_WIDTH / 2) - (32 / 2), SCREEN_HEIGHT - 10, 32, 8);

    Sprite<GameObject> *blocks[5][3];
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 5; j++) {
            blocks[i][j] = create_object(copy_object(paddle->getOam()), ((SCREEN_WIDTH / 5) * j) + 10, 5 + (10 * i), 32, 8);
        }
    }

    initScreen();

    while(1) {
        vsync();

        keys = readKeys();
        if(keys & KEY_LEFT) {
            paddle->dX(-VELOCITY);
            paddle->updatePositionDependingOnVelocity();
        }
        if(keys & KEY_RIGHT) {
            paddle->dX(VELOCITY);
            paddle->updatePositionDependingOnVelocity();
        }

        ball->getObj()->updatePositionDependingOnPaddle(paddle->getObj());

        if(ball->getY() >= (SCREEN_HEIGHT - ball->getObj()->getH())) {
            you_died();
        } else {
            for(int i = 0; i < 3; i++) {
                for(int j = 0; j < 5; j++) {
                    auto block = blocks[i][j];

                    if(!block->isHidden() && ball->collidesWith(block->getObj())) {
                        block->hide();
                        score++;

                        ball->updateVelocity(ball->getObj()->getDx(), -ball->getObj()->getDy());
                    }
                }
            }
        }


        paddle->positionInOAM();
        ball->positionInOAM();
    }

    return 0;
}