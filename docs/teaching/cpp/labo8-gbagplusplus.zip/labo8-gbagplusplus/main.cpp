
// TODO make Game class
// TODO make SpriteManager class
// TODO make Sprite class

// TODO move code from labo4-modeloplossing.txt to corresponding classes

int main() {
    while(true) {
        // TODO call Game.update()
    }
    return 0;
}