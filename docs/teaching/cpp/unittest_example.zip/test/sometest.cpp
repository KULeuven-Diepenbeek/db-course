
#include "gtest/gtest.h"
#include "./../src/somedef.h"

class SuiteName : public ::testing::Test {
    // setup en teardown hier
};

// gebruik bovenstaande suite
TEST_F(SuiteName, TrueIsTrue) {
    EXPECT_TRUE(true);
}
// losstaande test
TEST(AddTest, ShouldAddOneAndTo) {
    EXPECT_EQ(add(1, 2), 5);
}