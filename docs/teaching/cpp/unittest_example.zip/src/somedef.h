#ifndef _SOMEDEF_H
#define _SOMEDEF_H

int add(int one, int two) {
    return one + two;
}

#endif