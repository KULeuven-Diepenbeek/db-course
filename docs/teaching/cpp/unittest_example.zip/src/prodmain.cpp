#include "somedef.h"
#include <iostream>

using namespace std;

int main() {
    cout << "productie code - 1 plus 2 is " << add(1, 2) << endl;
    return 0;
}