//
// Created by Wouter Groeneveld on 08/11/18.
//

#include "interval.h"

bool Interval::inclusief(int ander) {
    return ander >= begin && ander <= einde;
}
